package com.example.cidsmsreader;

import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Internets con ;
    String getUrlManual;
    private static final int MY_PERMISSION_REQUEST = 0;
    EditText log_IPaddress;
    Button btn_sentURL;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        log_IPaddress = findViewById(R.id.log_IPaddress);
        btn_sentURL = findViewById(R.id.btn_sentURL);
        sharedPreferences = getSharedPreferences("getUrlIpAddress", MODE_PRIVATE);

        btn_sentURL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharedPreferences = getSharedPreferences("getUrlIpAddress", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("url", log_IPaddress.getText().toString());
                editor.apply();
            }
        });


    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permission[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permission, grantResults);
        switch (requestCode) {
            case MY_PERMISSION_REQUEST: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Thanks for permitting", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "Well, I can't do anything until you permit me!", Toast.LENGTH_LONG).show();
                }
            }
        }
    }
}