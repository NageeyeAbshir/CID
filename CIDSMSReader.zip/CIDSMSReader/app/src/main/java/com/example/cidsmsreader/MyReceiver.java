package com.example.cidsmsreader;

import static android.content.Context.MODE_PRIVATE;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

import java.net.URLEncoder;

public class MyReceiver extends BroadcastReceiver {

    private static final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
    private static final String TAG = "SmsBroadcastReceiver";

    private String msg, code_num = "";
    //url url = new url();
    Internets con = new Internets();
    String getUrlManual;
    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences mySharedPreferences = context.getSharedPreferences("getUrlIpAddress", MODE_PRIVATE);
        getUrlManual = mySharedPreferences.getString("url", "");
        if (intent.getAction().equals(SMS_RECEIVED)) {
            Bundle bundle = intent.getExtras();
            SmsMessage[] msgs;

            if (bundle != null) {
                try {
                    Object[] pdus = (Object[]) bundle.get("pdus");
                    msgs = new SmsMessage[pdus.length];

                    for (int i = 0; i < msgs.length; i++) {
                        msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                        code_num = msgs[i].getOriginatingAddress();
                        msg += msgs[i].getMessageBody();
                        //Toast.makeText(context, "Lacag  "+msg, Toast.LENGTH_LONG).show();
                    }

                    if (code_num.equals("192")) {
                        if (msg.contains("ka heshay")) {
                            String[] localPhone = msg.split(" ");
                            //Toast.makeText(context, "Tell: "+localPhone[5].split(",")[0] + " Price: "+localPhone[2].replace("$",""), Toast.LENGTH_LONG).show();
                            Log.i(TAG, localPhone[5].split(",")[0]);
                            String qry = "";
                            qry = URLEncoder.encode("tell", "UTF-8") +"="+ localPhone[5].split(",")[0];
                            qry += "&"+ URLEncoder.encode("price", "UTF-8") +"="+ localPhone[2].replace("$","");
                            String rest = con.getJson("http://"+ getUrlManual +"/criminal_investigation_sm/config/checksmslast.php",qry);
                            Toast.makeText(context, rest, Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(context, "Lacag ayaa dirtay sxp!", Toast.LENGTH_LONG).show();
                            Log.i(TAG, "Lacag EVC-PLUS ah ayaa dirtay sxp!");
                        }
                    } else if (code_num.equals("898")) {
                        if (msg.contains("ayaad ka Heshay")) {
                            String ty = "\\)";
                            String tys = "\\(";
                            String[] localPhone = msg.split(" ");//
                            String[] Tell = msg.split(ty);//
                            String[] localTell = Tell[0].split("252");//
                            //Toast.makeText(context,  "Tell: "+localTell[1].split(tys)[0] +" Price: "+localPhone[1].replace("$",""), Toast.LENGTH_LONG).show();
                            Log.i(TAG, localPhone[1].split("''")[0]);
                            String qry = "";
                            qry = URLEncoder.encode("getTell", "UTF-8") +"="+ localTell[1].split(tys)[0];
                            qry += "&"+ URLEncoder.encode("getPrice", "UTF-8") +"="+ localPhone[2].replace("$","");
                            String rest = con.getJson("http://"+ getUrlManual +"/criminal_investigation_sm/config/checksmslast.php",qry);
                            Toast.makeText(context, rest, Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(context, "Lacag ayaa dirtay sxp!", Toast.LENGTH_LONG).show();
                            Log.i(TAG, "Lacag JEEB ah ayaa dirtay sxp!");
                        }
                    } else if (code_num.equals("eDahab")) {
                        if (msg.contains("Ayaad Ka Heshay")) {
                            String[] localPhone = msg.split(" ");//
                            String[] localTell = msg.split("Lambarka");
                            //Toast.makeText(context,  "Tell: "+localTell[1].substring(0,9) +" Price: "+localPhone[0].replace("null",""), Toast.LENGTH_LONG).show();
                            Log.i(TAG, localPhone[1].split("''")[0]);
                            String qry = "";
                            qry = URLEncoder.encode("tell", "UTF-8") +"="+ localTell[1].substring(0,9);
                            qry += "&"+ URLEncoder.encode("price", "UTF-8") +"="+ localPhone[0].replace("null","");
                            String rest = con.getJson("http://"+ getUrlManual +"/criminal_investigation_sm/config/checksmslast.php",qry);
                            Toast.makeText(context, rest, Toast.LENGTH_LONG).show();
                        } else {
                            //Toast.makeText(context, "Lacag ayaa dirtay sxp! ", Toast.LENGTH_LONG).show();
                            Log.i(TAG, "Lacag eDahab ah ayaa dirtay sxp!");
                        }
                    }

                } catch (Exception e) {
                    Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        }

        // Markuu message soo dhacaba wuu kuu sheegaa...
        //Toast.makeText(context, "Message ayaa kuu soo dhacay", Toast.LENGTH_LONG).show();

    }
}